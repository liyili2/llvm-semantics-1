<!-- Copyright (c) 2015 K Team. All Rights Reserved. -->
To build the reference manual, run:
```
kompile ref-manual.k --main-module AUTO-INCLUDED-MODULE
kdoc
```
