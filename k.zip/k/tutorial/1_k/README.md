<!-- Copyright (c) 2014 K Team. All Rights Reserved. -->
# Learning K

We start by introducing the basic features of K by means of a series
of very simple languages.  The objective here is neither to learn those
languages nor to study their underlying paradigm, but simply to learn K.
